// Content script - Detects submissions on LeetCode and GeeksforGeeks
(function() {
  'use strict';

  // State management
  let lastSubmission = null;
  let lastSubmissionTime = 0;
  let debounceTimer = null;
  let observer = null;
  let isProcessing = false; // Flag to prevent concurrent processing
  
  const DEBOUNCE_DELAY = 2000; // 2 seconds
  const DUPLICATE_WINDOW = 30000; // 30 seconds - ignore duplicates within this window
  const PLATFORM = detectPlatform();

  // Platform detection
  function detectPlatform() {
    const hostname = window.location.hostname;
    const pathname = window.location.pathname;
    
    console.log('[DSA Sync] Checking platform:', { hostname, pathname });
    
    if (hostname.includes('leetcode.com')) {
      console.log('[DSA Sync] Platform detected: LeetCode');
      return 'leetcode';
    }
    if (hostname.includes('geeksforgeeks.org') && (pathname.includes('/problems/') || pathname.includes('/practice/'))) {
      console.log('[DSA Sync] Platform detected: GeeksforGeeks');
      return 'gfg';
    }
    if (hostname.includes('codingninjas.com') || hostname.includes('naukri.com')) {
      if (pathname.includes('/problems/') || pathname.includes('/code360/')) {
        console.log('[DSA Sync] Platform detected: CodingNinjas');
        return 'codingninjas';
      }
    }
    
    console.warn('[DSA Sync] Platform not detected:', hostname);
    return null;
  }

  // Platform-specific extractors
  const extractors = {
    leetcode: {
      isAccepted: () => {
        // Multiple ways to detect accepted
        const result = document.querySelector('[data-e2e-locator="submission-result"]');
        if (result && result.textContent.toLowerCase().includes('accepted')) return true;
        
        // Alternative: Check for success icon
        const successIcon = document.querySelector('[class*="success"]');
        if (successIcon && successIcon.textContent.toLowerCase().includes('accepted')) return true;
        
        // Alternative: Check page text
        const pageText = document.body.textContent.toLowerCase();
        return pageText.includes('accepted') && pageText.includes('runtime');
      },
      
      getTitle: () => {
        // Try multiple selectors first
        let titleEl = document.querySelector('[data-cy="question-title"]');
        if (titleEl && titleEl.textContent.trim()) return titleEl.textContent.trim();
        
        titleEl = document.querySelector('a[href*="/problems/"]');
        if (titleEl && titleEl.textContent.trim()) return titleEl.textContent.trim();
        
        titleEl = document.querySelector('.text-title-large');
        if (titleEl && titleEl.textContent.trim()) return titleEl.textContent.trim();
        
        titleEl = document.querySelector('div[class*="title"]');
        if (titleEl && titleEl.textContent.trim()) return titleEl.textContent.trim();
        
        // New selectors for updated LeetCode UI
        titleEl = document.querySelector('div[class*="text-title"]');
        if (titleEl && titleEl.textContent.trim()) return titleEl.textContent.trim();
        
        titleEl = document.querySelector('h1');
        if (titleEl && titleEl.textContent.trim()) return titleEl.textContent.trim();
        
        // Fallback: Get from URL (most reliable)
        const match = window.location.pathname.match(/\/problems\/([^\/]+)/);
        if (match) {
          // Convert "two-sum" to "Two Sum"
          return match[1]
            .split('-')
            .map(w => w.charAt(0).toUpperCase() + w.slice(1))
            .join(' ');
        }
        
        return null;
      },
      
      getDifficulty: () => {
        // Try multiple selectors
        let diffEl = document.querySelector('[diff]');
        if (diffEl) {
          const diff = diffEl.getAttribute('diff').toLowerCase();
          return ['easy', 'medium', 'hard'].includes(diff) ? diff : 'medium';
        }
        
        diffEl = document.querySelector('[class*="difficulty"]');
        if (diffEl) {
          const text = diffEl.textContent.toLowerCase();
          if (text.includes('easy')) return 'easy';
          if (text.includes('hard')) return 'hard';
          return 'medium';
        }
        
        // Default
        return 'medium';
      },
      
      getCode: () => {
        // Try Monaco editor (most common)
        let lines = document.querySelectorAll('.view-line');
        if (lines.length > 0) {
          const code = Array.from(lines)
            .map(line => line.textContent)
            .join('\n')
            .trim();
          if (code.length > 10) return code; // Ensure it's not empty
        }
        
        // Try CodeMirror
        lines = document.querySelectorAll('.CodeMirror-line');
        if (lines.length > 0) {
          const code = Array.from(lines)
            .map(line => line.textContent)
            .join('\n')
            .trim();
          if (code.length > 10) return code;
        }
        
        // Try textarea
        const textarea = document.querySelector('textarea[class*="code"]');
        if (textarea && textarea.value.trim().length > 10) return textarea.value.trim();
        
        // Try any textarea
        const anyTextarea = document.querySelector('textarea');
        if (anyTextarea && anyTextarea.value.trim().length > 10) return anyTextarea.value.trim();
        
        // Try pre or code tags
        const codeBlock = document.querySelector('pre code') || document.querySelector('pre');
        if (codeBlock && codeBlock.textContent.trim().length > 10) return codeBlock.textContent.trim();
        
        console.warn('[DSA Sync] Could not extract code from editor');
        return null;
      },
      
      getLanguage: () => {
        // Try button text
        let langBtn = document.querySelector('[id^="headlessui-listbox-button"]');
        if (langBtn) {
          const lang = langBtn.textContent.trim().toLowerCase();
          if (lang) return lang;
        }
        
        // Try dropdown
        langBtn = document.querySelector('[class*="lang"]');
        if (langBtn) {
          const lang = langBtn.textContent.trim().toLowerCase();
          if (lang) return lang;
        }
        
        // Default
        return 'javascript';
      },
    },

    gfg: {
      isAccepted: () => {
        console.log('[DSA Sync] Checking if GFG submission is accepted...');
        
        // Check for success panel
        const successPanel = document.querySelector('.ui.success.message');
        if (successPanel) {
          console.log('[DSA Sync] Found success panel');
          return true;
        }
        
        // Check for "Problem Solved Successfully" text
        const successText = document.body.textContent;
        if (successText.includes('Problem Solved Successfully') || 
            successText.includes('All test cases passed')) {
          console.log('[DSA Sync] Found success text');
          return true;
        }
        
        // Check old selectors
        const successResult = document.querySelector('.problems_submit_result__success');
        if (successResult) {
          console.log('[DSA Sync] Found success result element');
          return true;
        }
        
        // Check for "Correct Answer" text
        if (successText.includes('Correct Answer') || successText.includes('all test cases passed')) {
          console.log('[DSA Sync] Found correct answer text');
          return true;
        }
        
        // Check for success icon/badge
        const successIcon = document.querySelector('[class*="success"]');
        if (successIcon && successIcon.textContent.toLowerCase().includes('correct')) {
          console.log('[DSA Sync] Found success icon');
          return true;
        }
        
        console.log('[DSA Sync] No success indicators found');
        return false;
      },
      
      getTitle: () => {
        // Strategy 1: Try multiple DOM selectors
        const selectors = [
          '.problems_header_content__title__text',
          '.problem-title',
          '[class*="problem"][class*="title"]',
          'h1.problemTitle',
          'div.problemTitle',
          'h1'
        ];
        
        for (const selector of selectors) {
          const titleEl = document.querySelector(selector);
          if (titleEl) {
            const text = titleEl.textContent.trim();
            // Validate: title should be reasonable length and not contain code
            if (text && text.length > 3 && text.length < 200 && !text.includes('class ') && !text.includes('function ')) {
              console.log(`[DSA Sync] Found title via selector "${selector}":`, text);
              return text;
            }
          }
        }
        
        // Strategy 2: Get from URL (most reliable for GFG)
        const match = window.location.pathname.match(/\/problems\/([^\/]+)/);
        if (match) {
          const urlTitle = match[1]
            .split('-')
            .map(w => w.charAt(0).toUpperCase() + w.slice(1))
            .join(' ');
          console.log('[DSA Sync] Extracted title from URL:', urlTitle);
          return urlTitle;
        }
        
        console.warn('[DSA Sync] Could not extract title');
        return null;
      },
      
      getDifficulty: () => {
        const diffEl = document.querySelector('.problems_header_content__title__difficulty') ||
                       document.querySelector('[class*="difficulty"]');
        if (!diffEl) return 'medium';
        const text = diffEl.textContent.toLowerCase();
        if (text.includes('easy')) return 'easy';
        if (text.includes('hard')) return 'hard';
        return 'medium';
      },
      
      getCode: () => {
        // Try Ace editor
        let lines = document.querySelectorAll('.ace_line');
        if (lines.length > 0) {
          const code = Array.from(lines)
            .map(line => line.textContent)
            .join('\n')
            .trim();
          if (code.length > 10) return code;
        }
        
        // Try Monaco editor
        lines = document.querySelectorAll('.view-line');
        if (lines.length > 0) {
          const code = Array.from(lines)
            .map(line => line.textContent)
            .join('\n')
            .trim();
          if (code.length > 10) return code;
        }
        
        // Try textarea
        const textarea = document.querySelector('textarea');
        if (textarea && textarea.value.trim().length > 10) return textarea.value.trim();
        
        console.warn('[DSA Sync] Could not extract code from GFG editor');
        return null;
      },
      
      getLanguage: () => {
        // Try language dropdown
        let langEl = document.querySelector('.problems_header_language__dropdown');
        if (langEl && langEl.textContent.trim()) {
          return langEl.textContent.trim().toLowerCase();
        }
        
        // Try button with language
        langEl = document.querySelector('button[class*="language"]');
        if (langEl && langEl.textContent.trim()) {
          return langEl.textContent.trim().toLowerCase();
        }
        
        // Try select dropdown
        const selectEl = document.querySelector('select[class*="language"]');
        if (selectEl && selectEl.value) {
          return selectEl.value.toLowerCase();
        }
        
        // Default to cpp for GFG
        return 'cpp';
      },
    },

    codingninjas: {
      isAccepted: () => {
        // Check for "Accepted" or "Correct Answer" labels
        const statusLabel = document.querySelector('.status-label.accepted') || 
                           document.querySelector('.status-correct');
        if (statusLabel) return true;

        // Check for checkmark icon
        const successIcon = document.querySelector('mat-icon.icon-check') ||
                           document.querySelector('.success-icon');
        if (successIcon) return true;

        // Check page text
        const bodyText = document.body.textContent;
        return bodyText.includes('Correct Answer') || bodyText.includes('Problem Solved Successfully');
      },

      getTitle: () => {
        let titleEl = document.querySelector('a.problem-title') || 
                     document.querySelector('.problem-name') ||
                     document.querySelector('h1');
        if (titleEl) return titleEl.textContent.trim();

        // Fallback from URL
        const match = window.location.pathname.match(/\/problems\/([^\/]+)/) ||
                      window.location.pathname.match(/\/code360\/problems\/([^\/]+)/);
        if (match) {
          return match[1].split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
        }
        return null;
      },

      getDifficulty: () => {
        const diffEl = document.querySelector('codingninjas-difficulty-chip') || 
                       document.querySelector('.difficulty');
        if (diffEl) {
          const text = diffEl.textContent.toLowerCase();
          if (text.includes('easy')) return 'easy';
          if (text.includes('hard')) return 'hard';
          if (text.includes('moderate')) return 'medium';
        }
        return 'medium';
      },

      getCode: () => {
        // CodingNinjas uses Monaco/Studio editor
        const lines = document.querySelectorAll('.view-lines .view-line');
        if (lines.length > 0) {
          return Array.from(lines).map(line => line.textContent).join('\n').trim();
        }

        // Try textarea fallback
        const textarea = document.querySelector('textarea.inputarea');
        if (textarea && textarea.value.length > 10) return textarea.value;

        return null;
      },

      getLanguage: () => {
        const langEl = document.querySelector('.language-select .mat-select-value-text') ||
                       document.querySelector('.classroom-language-select .mat-select-value-text');
        if (langEl) {
          const text = langEl.textContent.trim().toLowerCase();
          if (text.includes('javascript')) return 'javascript';
          if (text.includes('python')) return 'python';
          if (text.includes('java')) return 'java';
          if (text.includes('c++') || text.includes('cpp')) return 'cpp';
          return text.split(' ')[0]; // Return first word (e.g., "javascript")
        }
        return 'javascript';
      },
    },
  };

  // Extract submission data
  function extractSubmissionData() {
    if (!PLATFORM || !extractors[PLATFORM]) {
      console.error('[DSA Sync] Unknown platform');
      return null;
    }

    const extractor = extractors[PLATFORM];

    try {
      // Check if submission was accepted
      if (!extractor.isAccepted()) {
        console.log('[DSA Sync] Not accepted, skipping');
        return null;
      }

      const title = extractor.getTitle();
      const code = extractor.getCode();

      console.log('[DSA Sync] Extraction attempt:', { 
        platform: PLATFORM,
        title: title || 'MISSING',
        titleLength: title ? title.length : 0,
        titlePreview: title ? title.substring(0, 50) : 'N/A',
        code: code ? `${code.length} chars` : 'MISSING',
        codePreview: code ? code.substring(0, 50) : 'N/A',
        url: window.location.href
      });

      // Validate required fields
      if (!title || !code) {
        console.warn('[DSA Sync] Missing required fields - will retry on next DOM change', { 
          title: !!title, 
          code: !!code 
        });
        return null;
      }

      const data = {
        title,
        difficulty: extractor.getDifficulty(),
        code,
        language: extractor.getLanguage(),
        platform: PLATFORM,
      };

      console.log('[DSA Sync] Full data:', {
        title: data.title,
        difficulty: data.difficulty,
        language: data.language,
        codeLength: data.code.length
      });

      // Create unique key for deduplication
      const submissionKey = `${title}-${PLATFORM}`;
      const currentTime = Date.now();
      
      // Check if this is a duplicate within the time window
      // Only skip if EXACT same submission within 30 seconds
      if (lastSubmission === submissionKey && (currentTime - lastSubmissionTime) < DUPLICATE_WINDOW) {
        console.log('[DSA Sync] Duplicate submission detected (within 30s window), skipping');
        return null;
      }

      // Update last submission tracking
      lastSubmission = submissionKey;
      lastSubmissionTime = currentTime;
      
      console.log('[DSA Sync] New submission, will process');
      return data;

    } catch (error) {
      console.error('[DSA Sync] Extraction error:', error);
      return null;
    }
  }

  // Handle submission detection
  function handleSubmission() {
    // Prevent concurrent processing
    if (isProcessing) {
      console.log('[DSA Sync] Already processing a submission, skipping');
      return;
    }
    
    clearTimeout(debounceTimer);
    
    debounceTimer = setTimeout(() => {
      const data = extractSubmissionData();
      
      if (data) {
        isProcessing = true; // Set flag
        console.log('[DSA Sync] Submission detected:', data.title);
        
        // Check if chrome.runtime is available
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) {
          console.error('[DSA Sync] Chrome runtime not available - extension context invalidated');
          showToast('⚠️ Please reload this page to sync', 'error');
          isProcessing = false;
          return;
        }
        
        // Wrap in try-catch to handle context invalidation
        try {
          // Wake up service worker first, then send submission
          chrome.runtime.sendMessage({ type: 'PING' }, (pingResponse) => {
            if (chrome.runtime.lastError) {
              console.warn('[DSA Sync] Service worker wake-up failed:', chrome.runtime.lastError);
              
              // Check if it's context invalidation error
              if (chrome.runtime.lastError.message?.includes('context invalidated')) {
                showToast('⚠️ Please reload this page to sync', 'error');
                isProcessing = false;
                return;
              }
            } else {
              console.log('[DSA Sync] Service worker is alive');
            }
            
            // Send submission (even if ping failed, try anyway)
            setTimeout(() => {
              try {
                chrome.runtime.sendMessage(
                  { type: 'SUBMISSION_DETECTED', data },
                  (response) => {
                    isProcessing = false; // Reset flag
                    
                    if (chrome.runtime.lastError) {
                      console.error('[DSA Sync] Message error:', chrome.runtime.lastError);
                      
                      if (chrome.runtime.lastError.message?.includes('context invalidated')) {
                        showToast('⚠️ Please reload this page to sync', 'error');
                      } else {
                        showToast('⚠️ Extension error - try reloading', 'error');
                      }
                      return;
                    }
                    
                    if (response?.success) {
                      if (response.data?.message === 'Already submitted') {
                         showToast('ℹ️ Already submitted', 'info');
                      } else if (response.data && response.data.githubSynced === false) {
                         showToast(`⚠️ Saved to DB, but GitHub failed: ${response.data.error || ''}`, 'error');
                      } else {
                         // Successfully saved and pushed to GitHub
                         showToast('✅ Synced to GitHub!', 'success');
                      }
                    } else {
                      let errMsg = response?.error;
                      if (typeof errMsg === 'object') {
                        errMsg = errMsg.message || errMsg.error || JSON.stringify(errMsg);
                      }
                      console.error('[DSA Sync] API Submission Rejected:', response?.error);
                      showToast(`⚠️ Sync failed: ${errMsg || 'Unknown error'}`, 'error');
                    }
                  }
                );
              } catch (error) {
                console.error('[DSA Sync] Send message error:', error);
                showToast('⚠️ Please reload this page', 'error');
                isProcessing = false;
              }
            }, 100);
          });
        } catch (error) {
          console.error('[DSA Sync] Runtime error:', error);
          showToast('⚠️ Please reload this page', 'error');
          isProcessing = false;
        }
      }
    }, DEBOUNCE_DELAY);
  }

  // Show toast notification
  function showToast(message, type = 'info') {
    // Remove existing toast
    const existing = document.getElementById('dsa-sync-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'dsa-sync-toast';
    toast.textContent = message;
    
    const styles = {
      position: 'fixed',
      top: '20px',
      right: '20px',
      padding: '12px 20px',
      borderRadius: '8px',
      fontSize: '14px',
      fontWeight: '500',
      zIndex: '999999',
      boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      transition: 'opacity 0.3s ease',
    };

    const colors = {
      success: { bg: '#10b981', color: '#fff' },
      error: { bg: '#ef4444', color: '#fff' },
      info: { bg: '#3b82f6', color: '#fff' },
    };

    Object.assign(toast.style, styles, {
      backgroundColor: colors[type].bg,
      color: colors[type].color,
    });

    document.body.appendChild(toast);

    // Auto remove after 3 seconds
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // Initialize observer
  function init() {
    if (!PLATFORM) {
      console.warn('[DSA Sync] Not on supported platform');
      return;
    }

    // Check if chrome extension APIs are available
    if (typeof chrome === 'undefined' || !chrome.runtime) {
      console.error('[DSA Sync] Chrome extension APIs not available');
      return;
    }

    console.log(`[DSA Sync] Initialized on ${PLATFORM}`);
    console.log('[DSA Sync] Extension ID:', chrome.runtime.id);

    // Observe DOM changes
    observer = new MutationObserver((mutations) => {
      // Check if any mutation contains submission result
      const hasSubmissionResult = mutations.some(mutation => {
        return Array.from(mutation.addedNodes).some(node => {
          if (node.nodeType !== 1) return false;
          const text = node.textContent?.toLowerCase() || '';
          
          // LeetCode patterns
          if (text.includes('accepted') && text.includes('runtime')) return true;
          if (text.includes('accepted') || text.includes('success')) return true;
          
          // GFG patterns
          if (text.includes('problem solved successfully')) return true;
          if (text.includes('all test cases passed')) return true;
          if (text.includes('correct answer')) return true;
          
          return false;
        });
      });

      if (hasSubmissionResult) {
        console.log('[DSA Sync] Submission result detected in DOM');
        handleSubmission();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
    
    // For GFG: Also listen for button clicks (Submit button)
    if (PLATFORM === 'gfg') {
      console.log('[DSA Sync] Setting up GFG submit button listener');
      
      // Listen for clicks on submit button
      document.addEventListener('click', (e) => {
        const target = e.target;
        if (target && (
          target.textContent?.includes('Submit') || 
          target.classList?.contains('submit') ||
          target.id?.includes('submit')
        )) {
          console.log('[DSA Sync] Submit button clicked, will check for success in 3 seconds');
          // Wait for submission to complete
          setTimeout(() => {
            handleSubmission();
          }, 3000);
        }
      }, true);
    }
  }

  // Cleanup on page unload
  window.addEventListener('beforeunload', () => {
    if (observer) observer.disconnect();
    clearTimeout(debounceTimer);
  });

  // Start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Test connection on load
  setTimeout(() => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
      console.log('[DSA Sync] Extension connected successfully');
      console.log('[DSA Sync] Extension ID:', chrome.runtime.id);
    } else {
      console.error('[DSA Sync] Extension not properly loaded - please reload extension');
    }
  }, 1000);

})();
